#!/bin/bash

uptime > /home/ec2-user/up.log
